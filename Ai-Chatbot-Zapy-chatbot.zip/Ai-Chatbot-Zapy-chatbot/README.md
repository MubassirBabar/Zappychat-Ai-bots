# Ai Chatbot - Zapy🤖
## Chat gpt powerd chat bot with Voice input
![image](https://user-images.githubusercontent.com/89455522/216750384-26bfbaa2-a905-4b1d-b01a-7c5ebf617d23.png)

> AI powerd chat bot uses chatgpt api to answer all answerable questions.
> Also uses predefind questions just format it by ur self.
> Questions are redirected to chat gpt if the question asked from outer scope.
> any way u can add questions or add a function which appends new questions from users and replies from chatgpt,
> will add the above feature after 😉.

### Voice - Mode🎙️
> use "/voice" to enable voice mode

![image](https://user-images.githubusercontent.com/89455522/216750250-174934bb-b4ef-491e-a06f-b4ff7a75acde.png)

> say "exit" to exit voice mode

![image](https://user-images.githubusercontent.com/89455522/216750282-87d837c1-64da-4083-8e7b-b734d33bf137.png)

### Weather☁️
It can also do some basic function like ,You can search weather of any city,
![image](https://user-images.githubusercontent.com/89455522/206867458-fe2ac3c8-6469-47d2-b110-072697901fc7.png)

## Basic_Mathematical_Operations➕✖️➖➗
It can also do some basic mathematics lile addition , subtraction , multiplication & division.
![image](https://user-images.githubusercontent.com/89455522/216750657-9bd560af-3a06-49ac-bd76-d361988be1d5.png)
select the operator, to exit type "exit"

## Other Functions(Voice Mode)
### Opens Apps🆕
> opens some predefined apps
![image](https://user-images.githubusercontent.com/89455522/216750740-e8e7f354-e6ea-495d-bb74-4def192f4c7c.png)

> you can configure more apps which you needed

### Controls Volume🔉 , Brightness 🔆 (brightness in beta)
> decrease the volume or increase the volume

![image](https://user-images.githubusercontent.com/89455522/216751211-6a0189a4-14e5-42ef-98cf-ca3e565e4508.png)

![image](https://user-images.githubusercontent.com/89455522/216751228-ea4ce238-6cf2-4c5b-861d-fbe14d14884f.png)

### Offline mode
> Learns from the users prompt & queries & after further analysis it responds to our queries ofline which will be more faster than api request & other online services.
