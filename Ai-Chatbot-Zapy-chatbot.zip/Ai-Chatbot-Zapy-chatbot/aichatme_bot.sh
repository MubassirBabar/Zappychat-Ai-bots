#!/bin/bash

aichatme_bot

