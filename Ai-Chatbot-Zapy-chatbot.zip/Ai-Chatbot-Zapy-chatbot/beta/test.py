from tensorflow.keras import optimizers, losses


optimizer = optimizers.rmsprop(lr=0.001)