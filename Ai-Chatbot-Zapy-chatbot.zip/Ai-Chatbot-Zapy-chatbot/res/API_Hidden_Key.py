# paste your api key from open ai here
def api_key():
    return "<Your_API_Key>"


APIKEY = "<Your_API_Key>"
